class ApkGenerateModal {
    __html = `
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5">Generar APK</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-3">
                <form class="__apk_form">
                    <div class="mb-3">
                        <label class="form-label">Nombre de la app</label>
                        <input type="text" class="form-control __apk_name" maxlength="30" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Paquete (ej: com.cliente.vpn)</label>
                        <input type="text" class="form-control __apk_package" maxlength="60"
                            pattern="^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*){1,5}$" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Ícono (PNG o JPG)</label>
                        <input type="file" class="form-control __apk_icon" accept=".png,.jpg,.jpeg" required>
                    </div>
                    <div class="__apk_error text-danger small mb-2" style="display:none;"></div>
                    <div class="__apk_progress text-center mb-2" style="display:none;">
                        <div class="spinner-border spinner-border-sm me-2" role="status"></div>
                        Generando APK, puede tardar un par de minutos...
                    </div>
                    <div class="__apk_result" style="display:none;">
                        <a href="#" class="btn btn-success w-100 __apk_download_link" download>Descargar APK</a>
                    </div>
                    <button type="submit" class="btn btn-dark w-100 __apk_submit">Generar</button>
                </form>
            </div>
        </div>
    </div>`;

    constructor() {
        this._element = document.createElement('div');
        this._element.classList.add('modal', 'fade');
        this._element.setAttribute('tabindex', '-1');
        this._element.innerHTML = this.__html;
        this.modal = new bootstrap.Modal(this._element);

        this._form = this._element.querySelector('.__apk_form');
        this._nameInput = this._element.querySelector('.__apk_name');
        this._packageInput = this._element.querySelector('.__apk_package');
        this._iconInput = this._element.querySelector('.__apk_icon');
        this._errorBox = this._element.querySelector('.__apk_error');
        this._progressBox = this._element.querySelector('.__apk_progress');
        this._resultBox = this._element.querySelector('.__apk_result');
        this._downloadLink = this._element.querySelector('.__apk_download_link');
        this._submitBtn = this._element.querySelector('.__apk_submit');

        this._form.addEventListener('submit', (e) => {
            e.preventDefault();
            this._generate();
        });
    }

    async _generate() {
        this._errorBox.style.display = 'none';
        this._resultBox.style.display = 'none';
        this._progressBox.style.display = 'block';
        this._submitBtn.disabled = true;

        const formData = new FormData();
        formData.append('name', this._nameInput.value.trim());
        formData.append('package', this._packageInput.value.trim());
        formData.append('icon', this._iconInput.files[0]);

        try {
            const response = await fetch('/api/apk/generate', { method: 'POST', body: formData });
            const data = await response.json().catch(() => ({}));

            if (!response.ok) {
                throw new Error(data?.message || 'No se pudo generar el APK.');
            }

            this._downloadLink.href = data.url;
            this._resultBox.style.display = 'block';
        } catch (err) {
            this._errorBox.textContent = err.message || 'Error inesperado.';
            this._errorBox.style.display = 'block';
        } finally {
            this._progressBox.style.display = 'none';
            this._submitBtn.disabled = false;
        }
    }

    show() {
        this._errorBox.style.display = 'none';
        this._resultBox.style.display = 'none';
        this._form.reset();
        this.modal.show();
    }

    hide() {
        this.modal.hide();
    }
}

export default ApkGenerateModal;
