import * as fs from 'fs';
import * as path from 'path';
import * as crypto from 'crypto';
import { execFile } from 'child_process';
import Authentication from '../../../middlewares/authentication';
import { FastifyReply, FastifyRequest, RouteOptions } from 'fastify';

// El generador vive fuera del panel (lo instala apk-generator.sh en el VPS).
const APKGEN_SCRIPT = process.env.APKGEN_SCRIPT || '/opt/apk-generator/apk-generator.sh';
const APKGEN_TMP = process.env.APKGEN_TMP || '/tmp/apkgen-uploads';
// Carpeta pública: fastify-static ya sirve todo lo que esté bajo frontend/public.
const DOWNLOAD_DIR = path.resolve(__dirname, '../../../../frontend/public/downloads/apk');
const PACKAGE_RE = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){1,5}$/;
const MAX_ICON_BYTES = 5 * 1024 * 1024;
const BUILD_TIMEOUT_MS = 6 * 60 * 1000; // el build tarda 1-3 min; dejamos margen

fs.mkdirSync(APKGEN_TMP, { recursive: true });
fs.mkdirSync(DOWNLOAD_DIR, { recursive: true });

function runGenerator(args: string[]): Promise<string> {
  return new Promise((resolve, reject) => {
    execFile(
      'bash',
      [APKGEN_SCRIPT, 'build', ...args],
      { timeout: BUILD_TIMEOUT_MS, maxBuffer: 10 * 1024 * 1024 },
      (err, stdout, stderr) => {
        if (err) return reject(new Error(stderr?.trim() || stdout?.trim() || err.message));
        const lines = stdout.trim().split('\n').filter(Boolean);
        const apkPath = lines[lines.length - 1];
        if (!apkPath || !apkPath.endsWith('.apk')) {
          return reject(new Error(stderr?.trim() || stdout?.trim() || 'El generador no devolvió un APK.'));
        }
        resolve(apkPath.trim());
      }
    );
  });
}

export default {
  url: '/api/apk/generate',
  method: 'POST',
  onRequest: [Authentication.user],
  config: {
    // El build es pesado (CPU/RAM); limitamos por usuario para no saturar el VPS.
    rateLimit: {
      max: 5,
      timeWindow: '10 minutes',
    },
  },
  handler: async (req: FastifyRequest, reply: FastifyReply) => {
    if (!fs.existsSync(APKGEN_SCRIPT)) {
      reply.status(503);
      throw new Error('El generador de APK no está instalado en este servidor.');
    }

    const parts = req.parts();
    let appName = '';
    let packageName = '';
    let iconPath = '';

    for await (const part of parts) {
      if (part.type === 'file' && part.fieldname === 'icon') {
        const tmpFile = path.join(APKGEN_TMP, `${crypto.randomUUID()}-${part.filename || 'icon'}`);
        let size = 0;
        const writeStream = fs.createWriteStream(tmpFile);
        for await (const chunk of part.file) {
          size += chunk.length;
          if (size > MAX_ICON_BYTES) {
            writeStream.destroy();
            fs.unlink(tmpFile, () => {});
            reply.status(400);
            throw new Error('El ícono no puede pesar más de 5 MB.');
          }
          writeStream.write(chunk);
        }
        writeStream.end();
        iconPath = tmpFile;
      } else if (part.type === 'field') {
        if (part.fieldname === 'name') appName = String(part.value).trim();
        if (part.fieldname === 'package') packageName = String(part.value).trim();
      }
    }

    if (!appName || appName.length > 30) {
      reply.status(400);
      throw new Error('El nombre de la app es obligatorio (máximo 30 caracteres).');
    }
    if (!PACKAGE_RE.test(packageName) || packageName.length > 60) {
      reply.status(400);
      throw new Error('El nombre de paquete no es válido. Ejemplo: com.cliente.vpn');
    }
    if (!iconPath) {
      reply.status(400);
      throw new Error('Debes subir un ícono.');
    }

    // El ID siempre viene de la sesión: nadie puede pedir el APK de otra cuenta.
    const userId = req.user!.id;

    try {
      const generatedPath = await runGenerator([
        '--package', packageName,
        '--name', appName,
        '--icon', iconPath,
        '--user-id', userId,
      ]);

      const token = crypto.randomUUID();
      const destName = `${token}.apk`;
      const destPath = path.join(DOWNLOAD_DIR, destName);
      fs.copyFileSync(generatedPath, destPath);

      // El link vence solo: se borra a los 30 minutos para no acumular APKs.
      setTimeout(() => fs.unlink(destPath, () => {}), 30 * 60 * 1000);

      reply.send({ url: `/downloads/apk/${destName}` });
    } catch (err: any) {
      reply.status(500);
      throw new Error('No se pudo generar el APK. ' + (err?.message || ''));
    } finally {
      fs.unlink(iconPath, () => {});
    }
  },
} as RouteOptions;
